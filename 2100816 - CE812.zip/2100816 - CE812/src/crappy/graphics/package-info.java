/**
 * Are you too burnt out to create your own graphics rendering solution from scratch for your Crappy games?
 *
 * Yes?
 *
 * Same here. That's why I made this, to handle most of the drawing for you (if your standards are low enough, that is)
 * @author Rachel Lowe
 */
package crappy.graphics;
/*
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/.
 */