/**
 * A bunch of miscellaneous utility classes I made when making CRAPPY,
 * which you can now use yourself if your standards are low enough!
 *
 * @author Rachel Lowe
 */
package crappy.utils;
/*
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/.
 */