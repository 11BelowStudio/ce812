/**
 * CRAPPY containers to hold your CRAP in!
 *
 * @author Rachel Lowe
 */
package crappy.utils.containers;