/**
 * CRAPPY:
 * Cool Realism-Adjacent Physics Package, Y'know?
 *
 * A physics engine created by Rachel Lowe for the CE812 Physics-Based Games module.
 *
 *
 * PLEASE NOTE: this uses constant gravity (not distance-dependent), but it does use distant-dependent connectors,
 * a customizable euler integrator (free to choose how many substeps you want it to take), tweakable gravity,
 * a really bad but functional interface which you can use for low-effort rendering, and a bunch of other
 * cool documented (and undocumented) features!
 * @author Rachel Lowe
 */
package crappy;
/*
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/.
 */