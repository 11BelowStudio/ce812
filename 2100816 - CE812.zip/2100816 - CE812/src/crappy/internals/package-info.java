/**
 * Once upon a time, I decided to try using annotations to warn you when you're doing something stupid.
 *
 * I'm not sure if it worked.
 *
 * Anywho, chances are that you won't really have much of a reason to go here. Like, ever.
 */
package crappy.internals;
/*
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/.
 */