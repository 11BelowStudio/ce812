package crappyGame;

public interface IChangeScenes {


    void levelWon(final double fuelUsed, final int livesLeft);

    void levelLost();
}
