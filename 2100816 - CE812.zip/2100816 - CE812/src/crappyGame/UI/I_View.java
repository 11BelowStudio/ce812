package crappyGame.UI;

public interface I_View {
}
