package crappyGame.GameObjects;

import crappy.CrappyWorld;

public interface Respawnable {

    public boolean respawn(final CrappyWorld w);
}
