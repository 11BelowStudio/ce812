package crappyGame.GameObjects;

public interface Updatable {

    void update(double delta);
}
